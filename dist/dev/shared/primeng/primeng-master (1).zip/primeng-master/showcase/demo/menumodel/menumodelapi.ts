import {Component} from '@angular/core';
import {CodeHighlighter} from '../../../components/codehighlighter/codehighlighter';

@Component({
    templateUrl: 'showcase/demo/menumodel/menumodelapi.html',
    directives: [CodeHighlighter]
})
export class MenuModelApi {

}