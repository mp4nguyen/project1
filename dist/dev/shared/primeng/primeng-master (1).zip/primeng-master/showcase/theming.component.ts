import {Component} from '@angular/core';

@Component({
    templateUrl: 'showcase/theming.component.html'
})
export class ThemingComponent {

}