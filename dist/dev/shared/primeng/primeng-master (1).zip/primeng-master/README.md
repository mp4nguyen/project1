# PrimeNG
UI Components for AngularJS 2

See [PrimeNG homepage](http://www.primefaces.org/primeng) for live showcase and documentation.

![alt text](http://www.primefaces.org/images/primeng.png "PrimeNG")
