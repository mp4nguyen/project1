import {Component} from '@angular/core';

@Component({
    selector: 'footer',
    template: '<ng-content></ng-content>'
})
export class Footer {}